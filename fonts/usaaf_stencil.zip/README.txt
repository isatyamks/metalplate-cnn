USAAF Stencil and USAAF Serial Stencil are �4thFG_TwoGuns, all rights reserved.

These fonts are free for personal use.

To access additional characters, use the Windows Character Map:

1. Go to Start->Programs->Accessories->System Tools->Character Map

2. Pull up USAAF Stencil in the Font drop-down menu

3. Select the character you would like to use

4. Hit "Copy", or CTRL-C

5. Paste into your document or artwork.

6. You may also note the "Keystroke: Alt+XXXX" message in the lower right of the Character Map Window. You can use these codes within your application to bring up the alternate characters. Just press "Num Lock" on the number pad on your keyboard, hold down ALT and type in the four digit code indicated. Voila!

Enjoy!
4thFG_TwoGuns